
url = "ProjectContent/App.qml"
import_paths = [".",]
