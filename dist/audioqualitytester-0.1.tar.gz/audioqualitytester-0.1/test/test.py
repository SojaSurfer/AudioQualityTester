import pygame.mixer as mixer
from pydub import AudioSegment
import os
import tempfile
import shutil
from pathlib import Path




class AudioPlayer:
    
    def __init__(self):
        mixer.init()
        self._playType = None
        self.temp_dir = tempfile.mkdtemp()  # Temporary directory for handling lossless files
        self.current_file = None
        # modelLogger.debug(f'{self.__class__.__qualname__} initialized')

    def _convert_lossless_to_wav(self, filepath: str) -> str:
        """Convert lossless audio (e.g., flac, ogg) to wav for pygame playback."""
        audio = AudioSegment.from_file(filepath)
        wav_file = os.path.join(self.temp_dir, "temp_audio.wav")
        audio.export(wav_file, format="wav")
        return wav_file

    def playFile(self, file: str, startTime: int = 0) -> None:
        """Play both lossy and lossless audio."""
        file = str(file)
        print('playFile method:', file)
        self.stopFile()  # Stop any currently playing audio

        if file.endswith('.mp3'):
            self._playType = 'lossy'
            mixer.music.load(file)
            mixer.music.play(start=startTime)
        else:
            self._playType = 'lossless'
            wav_file = self._convert_lossless_to_wav(file)  # Convert to wav if necessary
            self.current_file = wav_file
            mixer.music.load(wav_file)
            mixer.music.play(start=startTime)
        
        return None

    def stopFile(self) -> None:
        """Stop any audio currently playing."""
        if mixer.music.get_busy():
            mixer.music.stop()

        # Cleanup temporary wav file after stopping lossless audio
        if self._playType == 'lossless' and self.current_file and os.path.exists(self.current_file):
            os.remove(self.current_file)
            self.current_file = None

        self._playType = None
        return None

    def cleanup(self) -> None:
        """Clean up any remaining resources like temp directories."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        return None

# Example usage
if __name__ == '__main__':
    player = AudioPlayer()


    # Play a FLAC file (or any other lossless format)
    player.playFile('/Users/julian/Documents/5 - Dev/51 Programming Languages/511 Python/511.1 Unfinished Projects/AudioQualityTester/test/temp/audio/07 Huck And Jim.wav', 10)

    import time
    time.sleep(4)
    player.stopFile()

    # Cleanup
    player.cleanup()